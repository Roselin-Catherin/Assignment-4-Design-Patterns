package lunar.rover.vehicle;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * JUnit tests for the Lunar Rover State pattern.
 *
 * @author Roselin
 * @version 2.0
 */
public class LunarRoverVehicleTest {

    private LunarRoverVehicle rover;
    private ByteArrayOutputStream out;
    private PrintStream originalOut;

    @Before
    public void setUp() {
        originalOut = System.out;
        out = new ByteArrayOutputStream();
        System.setOut(new PrintStream(out));
        rover = new LunarRoverVehicle();
    }

    @After
    public void tearDown() {
        System.setOut(originalOut);
    }

    private String state() {
        return rover.getState().getName();
    }

    // Driving

    @Test
    public void testStartsAtRest() {
        assertTrue(rover.getState() instanceof AtRest);
        assertEquals(0, rover.getSpeed(), 0.001);
    }

    @Test
    public void testLeftTapAccelerates() {
        rover.leftPedal(0.3);
        assertEquals("ACCELERATING", state());
        rover.tick(5);
        assertEquals(5, rover.getSpeed(), 0.001);
    }

    @Test
    public void testSpeedLimitForward() {
        rover.leftPedal(0.3);
        rover.tick(20);
        assertEquals(12, rover.getSpeed(), 0.001);
    }

    @Test
    public void testRightHoldCruisesAndKeepsSpeed() {
        rover.leftPedal(0.3);
        rover.tick(5);
        rover.rightPedal(4);
        assertEquals("CRUISING", state());
        rover.tick(3);
        assertEquals(5, rover.getSpeed(), 0.001);
    }

    @Test
    public void testDeceleratesBackToAtRest() {
        rover.leftPedal(0.3);
        rover.tick(5);
        rover.rightPedal(0.4);
        assertEquals("DECELERATING", state());
        rover.tick(10);
        assertEquals("AT_REST", state());
        assertEquals(0, rover.getSpeed(), 0.001);
    }

    @Test
    public void testSwitchIgnoredWhileMoving() {
        rover.leftPedal(0.3);
        rover.tick(5);
        rover.flipSwitch();
        assertEquals("ACCELERATING", state());
    }

    @Test
    public void testReversing() {
        rover.leftPedal(3.5);
        assertEquals("REVERSING", state());
        rover.tick(10);
        assertEquals(-4, rover.getSpeed(), 0.001);
        rover.rightPedal(0.2);
        assertEquals("AT_REST", state());
        assertEquals(0, rover.getSpeed(), 0.001);
    }

    @Test
    public void testUnhandledEventIgnored() {
        rover.rightPedal(0.3);
        rover.leftDoubleTap();
        assertEquals("AT_REST", state());
    }

    // Cameras

    @Test
    public void testSwitchAtRestGoesToIdle() {
        rover.flipSwitch();
        assertEquals("IDLE", state());
    }

    @Test
    public void testColorCameraTakesPicture() {
        rover.flipSwitch();
        rover.leftPedal(6);
        assertEquals("COLOR_READY", state());
        rover.leftPedal(0.5);
        assertTrue(out.toString().contains("picture taken"));
        assertEquals("COLOR_READY", state());
    }

    @Test
    public void testSelfTimerTakesPictureAfterTenSeconds() {
        rover.flipSwitch();
        rover.leftPedal(11);
        assertEquals("CAM16_READY", state());
        rover.leftPedal(5);
        assertEquals("CAM16_SELF_TIMER", state());
        rover.tick(9);
        assertFalse(out.toString().contains("picture taken"));
        rover.tick(1);
        assertTrue(out.toString().contains("picture taken"));
        assertEquals("CAM16_READY", state());
    }

    @Test
    public void testRightTapLeavesCamera() {
        rover.flipSwitch();
        rover.leftPedal(6);
        rover.rightPedal(0.3);
        assertEquals("IDLE", state());
    }

    // Drill

    @Test
    public void testDrillOnAndOff() {
        rover.flipSwitch();
        rover.leftDoubleTap();
        assertEquals("DRILL_OFF", state());
        rover.leftPedal(0.4);
        assertEquals("DRILL_ON", state());
        assertTrue(out.toString().contains("drill started"));
        rover.leftPedal(0.4);
        assertEquals("DRILL_OFF", state());
        assertTrue(out.toString().contains("drill stopped"));
    }

    @Test
    public void testSwitchStopsDrill() {
        rover.flipSwitch();
        rover.leftDoubleTap();
        rover.leftPedal(0.4);
        rover.flipSwitch();
        assertEquals("AT_REST", state());
        assertTrue(out.toString().contains("drill stopped"));
    }
}
