package lunar.rover.vehicle;

/**
 * Rover is stopped.
 *
 * @author Roselin
 * @version 2.0
 */
public class AtRest extends DrivingState {

    @Override
    public String getName() {
        return "AT_REST";
    }

    @Override
    public void enter(LunarRoverVehicle rover) {
        rover.setSpeed(0);
    }

    @Override
    public void leftPedal(LunarRoverVehicle rover, double seconds) {
        if (LunarRoverVehicle.isTap(seconds)) {
            rover.changeTo(new Accelerating());
        } else if (seconds > 3) {
            rover.changeTo(new Reversing());
        }
    }
}
