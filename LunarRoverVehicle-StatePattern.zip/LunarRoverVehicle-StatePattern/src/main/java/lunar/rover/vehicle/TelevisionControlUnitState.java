package lunar.rover.vehicle;

/**
 * Parent of the camera and drill devices. A right tap leaves the active
 * device and goes back to Idle.
 *
 * @author Roselin
 * @version 2.0
 */
public abstract class TelevisionControlUnitState extends CameraAndDrillState {

    @Override
    public void rightPedal(LunarRoverVehicle rover, double seconds) {
        if (LunarRoverVehicle.isTap(seconds)) {
            rover.changeTo(new Idle());
        }
    }
}
