package lunar.rover.vehicle;

/**
 * Drill is running. It starts on entry and stops on exit, so leaving
 * this state any way (tap, right tap or switch) always stops the drill.
 *
 * @author Roselin
 * @version 2.0
 */
public class DrillOn extends TelevisionControlUnitState {

    @Override
    public String getName() {
        return "DRILL_ON";
    }

    @Override
    public void enter(LunarRoverVehicle rover) {
        rover.startDrill();
    }

    @Override
    public void exit(LunarRoverVehicle rover) {
        rover.stopDrill();
    }

    @Override
    public void leftPedal(LunarRoverVehicle rover, double seconds) {
        if (LunarRoverVehicle.isTap(seconds)) {
            rover.changeTo(new DrillOff());
        }
    }
}
