package lunar.rover.vehicle;

/**
 * Apollo 15 Lunar Rover, redesigned with the State pattern.
 * This is the context class: it keeps the current state and the speed,
 * and passes every event to the current state object.
 *
 * Pedal input rules:
 *   tap        = pedal pressed and released in under 1 s
 *   hold(t)    = pedal held for t seconds, checked when it is released
 *   double tap = two taps within 0.5 s
 *
 * @author Roselin
 * @version 2.0
 */
public final class LunarRoverVehicle {

    static final double TAP_LIMIT = 1.0;      // seconds
    static final double MAX_FORWARD = 12.0;   // km/h
    static final double MAX_REVERSE = 4.0;    // km/h
    static final double ACCEL = 1.0;          // km/h per second
    static final double TIMER_DELAY = 10.0;   // seconds

    /** Current state, all behaviour is delegated to it. */
    private RoverState state;

    /** Current speed, negative when reversing. */
    private double speed;

    public LunarRoverVehicle() {
        System.out.println("Rover powered on");
        changeTo(new AtRest());
    }

    /** Runs the exit action of the old state and the entry action of the new one. */
    void changeTo(RoverState next) {
        if (state != null) {
            state.exit(this);
        }
        System.out.println("  -> " + next.getName());
        state = next;
        state.enter(this);
    }

    static boolean isTap(double seconds) {
        return seconds < TAP_LIMIT;
    }

    // events

    public void leftPedal(double seconds) {
        System.out.println("left pedal " + seconds + "s");
        state.leftPedal(this, seconds);
    }

    public void rightPedal(double seconds) {
        System.out.println("right pedal " + seconds + "s");
        state.rightPedal(this, seconds);
    }

    public void leftDoubleTap() {
        System.out.println("left double tap");
        state.leftDoubleTap(this);
    }

    public void flipSwitch() {
        System.out.println("flip switch");
        state.flipSwitch(this);
    }

    /** Lets time pass so speed changes and the self timer can run. */
    public void tick(double seconds) {
        state.tick(this, seconds);
    }

    // actions

    void takePicture() {
        System.out.println("  * picture taken");
    }

    void startDrill() {
        System.out.println("  * drill started");
    }

    void stopDrill() {
        System.out.println("  * drill stopped");
    }

    public RoverState getState() {
        return state;
    }

    public double getSpeed() {
        return speed;
    }

    void setSpeed(double speed) {
        this.speed = speed;
    }

    // sample run, same steps as the original version

    public static void main(String[] args) {
        LunarRoverVehicle rover = new LunarRoverVehicle();

        System.out.println("\n-- driving forward --");
        rover.leftPedal(0.3);
        rover.tick(5);
        System.out.println("  speed = " + rover.getSpeed());
        rover.rightPedal(4);              // cruise
        rover.tick(3);
        System.out.println("  speed = " + rover.getSpeed());
        rover.flipSwitch();               // refused, still moving
        rover.rightPedal(0.4);            // slow down
        rover.tick(10);                   // reaches 0, back to AtRest

        System.out.println("\n-- reversing --");
        rover.leftPedal(3.5);
        rover.tick(2);
        System.out.println("  speed = " + rover.getSpeed());
        rover.rightPedal(0.2);

        System.out.println("\n-- cameras --");
        rover.flipSwitch();
        rover.leftPedal(6);               // color camera
        rover.leftPedal(0.5);             // picture
        rover.leftPedal(5);               // self timer
        rover.tick(10);
        rover.rightPedal(0.3);            // back to idle
        rover.leftPedal(11);              // 16mm camera
        rover.leftPedal(0.5);
        rover.rightPedal(0.3);

        System.out.println("\n-- drill --");
        rover.leftDoubleTap();
        rover.leftPedal(0.4);             // drill on
        rover.flipSwitch();               // exit stops the drill
        System.out.println("\nfinal state: " + rover.getState().getName());
    }
}
