package lunar.rover.vehicle;

/**
 * Drill selected but not running.
 *
 * @author Roselin
 * @version 2.0
 */
public class DrillOff extends TelevisionControlUnitState {

    @Override
    public String getName() {
        return "DRILL_OFF";
    }

    @Override
    public void leftPedal(LunarRoverVehicle rover, double seconds) {
        if (LunarRoverVehicle.isTap(seconds)) {
            rover.changeTo(new DrillOn());
        }
    }
}
