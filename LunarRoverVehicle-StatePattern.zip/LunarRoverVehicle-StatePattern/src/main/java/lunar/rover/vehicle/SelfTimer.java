package lunar.rover.vehicle;

/**
 * Self timer of a camera. After TIMER_DELAY seconds it takes a picture
 * and goes back to the Ready state of the same camera.
 *
 * @author Roselin
 * @version 2.0
 */
public class SelfTimer extends TelevisionControlUnitState {

    /** Which camera is active. */
    private final String camera;

    /** Seconds spent waiting in this state. */
    private double timerCount;

    public SelfTimer(String camera) {
        this.camera = camera;
    }

    @Override
    public String getName() {
        return camera + "_SELF_TIMER";
    }

    @Override
    public void enter(LunarRoverVehicle rover) {
        timerCount = 0;
    }

    @Override
    public void tick(LunarRoverVehicle rover, double seconds) {
        timerCount += seconds;
        if (timerCount >= LunarRoverVehicle.TIMER_DELAY) {
            rover.takePicture();
            rover.changeTo(new CameraReady(camera));
        }
    }
}
