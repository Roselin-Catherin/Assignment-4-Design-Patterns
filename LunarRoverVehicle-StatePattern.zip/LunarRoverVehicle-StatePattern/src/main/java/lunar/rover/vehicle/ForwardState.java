package lunar.rover.vehicle;

/**
 * Parent of Accelerating, Decelerating and Cruising.
 * Handles "when (speed = 0)": once the rover stops it goes back to AtRest.
 *
 * @author Roselin
 * @version 2.0
 */
public abstract class ForwardState extends DrivingState {

    @Override
    public void tick(LunarRoverVehicle rover, double seconds) {
        updateSpeed(rover, seconds);
        if (rover.getSpeed() == 0) {
            rover.changeTo(new AtRest());
        }
    }

    /** Each forward state changes the speed in its own way. */
    protected abstract void updateSpeed(LunarRoverVehicle rover, double seconds);
}
