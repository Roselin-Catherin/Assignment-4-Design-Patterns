package lunar.rover.vehicle;

/**
 * Parent of all Driving states. The switch only moves the rover to the
 * camera and drill controls when it is standing still [speed = 0].
 *
 * @author Roselin
 * @version 2.0
 */
public abstract class DrivingState implements RoverState {

    @Override
    public void flipSwitch(LunarRoverVehicle rover) {
        if (rover.getSpeed() == 0) {
            rover.changeTo(new Idle());
        } else {
            System.out.println("  rover still moving, switch ignored");
        }
    }
}
