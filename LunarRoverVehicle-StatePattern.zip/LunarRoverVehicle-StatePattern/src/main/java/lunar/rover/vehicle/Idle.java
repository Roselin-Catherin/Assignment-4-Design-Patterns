package lunar.rover.vehicle;

/**
 * No camera or drill selected yet.
 *
 * @author Roselin
 * @version 2.0
 */
public class Idle extends CameraAndDrillState {

    @Override
    public String getName() {
        return "IDLE";
    }

    @Override
    public void leftPedal(LunarRoverVehicle rover, double seconds) {
        if (seconds >= 5 && seconds < 10) {
            rover.changeTo(new CameraReady("COLOR"));
        } else if (seconds >= 10) {
            rover.changeTo(new CameraReady("CAM16"));
        }
    }

    @Override
    public void leftDoubleTap(LunarRoverVehicle rover) {
        rover.changeTo(new DrillOff());
    }
}
