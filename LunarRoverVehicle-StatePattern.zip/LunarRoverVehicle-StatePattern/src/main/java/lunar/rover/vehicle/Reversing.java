package lunar.rover.vehicle;

/**
 * Rover moves backwards, speed is negative and stops at -MAX_REVERSE.
 *
 * @author Roselin
 * @version 2.0
 */
public class Reversing extends DrivingState {

    @Override
    public String getName() {
        return "REVERSING";
    }

    @Override
    public void rightPedal(LunarRoverVehicle rover, double seconds) {
        if (LunarRoverVehicle.isTap(seconds)) {
            rover.changeTo(new AtRest());
        }
    }

    @Override
    public void tick(LunarRoverVehicle rover, double seconds) {
        double speed = rover.getSpeed() - LunarRoverVehicle.ACCEL * seconds;
        rover.setSpeed(Math.max(-LunarRoverVehicle.MAX_REVERSE, speed));
    }
}
