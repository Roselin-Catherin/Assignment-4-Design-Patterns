package lunar.rover.vehicle;

/**
 * Ready state of a camera. Used for both the color camera ("COLOR")
 * and the 16 mm camera ("CAM16") since they behave the same way.
 *
 * @author Roselin
 * @version 2.0
 */
public class CameraReady extends TelevisionControlUnitState {

    /** Which camera is active, so we come back to the right one. */
    private final String camera;

    public CameraReady(String camera) {
        this.camera = camera;
    }

    @Override
    public String getName() {
        return camera + "_READY";
    }

    @Override
    public void leftPedal(LunarRoverVehicle rover, double seconds) {
        if (LunarRoverVehicle.isTap(seconds)) {
            rover.takePicture();
        } else if (seconds >= 5) {
            rover.changeTo(new SelfTimer(camera));
        }
    }
}
