package lunar.rover.vehicle;

/**
 * Rover keeps its current speed.
 *
 * @author Roselin
 * @version 2.0
 */
public class Cruising extends ForwardState {

    @Override
    public String getName() {
        return "CRUISING";
    }

    @Override
    public void leftPedal(LunarRoverVehicle rover, double seconds) {
        if (LunarRoverVehicle.isTap(seconds)) {
            rover.changeTo(new Accelerating());
        }
    }

    @Override
    public void rightPedal(LunarRoverVehicle rover, double seconds) {
        if (LunarRoverVehicle.isTap(seconds)) {
            rover.changeTo(new Decelerating());
        }
    }

    @Override
    protected void updateSpeed(LunarRoverVehicle rover, double seconds) {
        // hold speed
    }
}
