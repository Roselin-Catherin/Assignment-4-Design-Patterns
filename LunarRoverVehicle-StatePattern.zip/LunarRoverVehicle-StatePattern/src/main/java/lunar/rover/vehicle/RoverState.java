package lunar.rover.vehicle;

/**
 * One state of the Lunar Rover. Each state decides how it reacts to the
 * pedals, the switch and the passing of time. Events a state does not
 * care about are ignored, so the default methods do nothing.
 *
 * @author Roselin
 * @version 2.0
 */
public interface RoverState {

    /** Name printed when the rover enters this state. */
    String getName();

    /** Entry action. */
    default void enter(LunarRoverVehicle rover) { }

    /** Exit action. */
    default void exit(LunarRoverVehicle rover) { }

    default void leftPedal(LunarRoverVehicle rover, double seconds) { }

    default void rightPedal(LunarRoverVehicle rover, double seconds) { }

    default void leftDoubleTap(LunarRoverVehicle rover) { }

    default void flipSwitch(LunarRoverVehicle rover) { }

    default void tick(LunarRoverVehicle rover, double seconds) { }
}
