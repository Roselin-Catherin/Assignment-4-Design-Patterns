package lunar.rover.vehicle;

/**
 * Speed goes up by ACCEL every second, up to MAX_FORWARD.
 *
 * @author Roselin
 * @version 2.0
 */
public class Accelerating extends ForwardState {

    @Override
    public String getName() {
        return "ACCELERATING";
    }

    @Override
    public void rightPedal(LunarRoverVehicle rover, double seconds) {
        if (LunarRoverVehicle.isTap(seconds)) {
            rover.changeTo(new Decelerating());
        } else if (seconds > 3) {
            rover.changeTo(new Cruising());
        }
    }

    @Override
    protected void updateSpeed(LunarRoverVehicle rover, double seconds) {
        double speed = rover.getSpeed() + LunarRoverVehicle.ACCEL * seconds;
        rover.setSpeed(Math.min(LunarRoverVehicle.MAX_FORWARD, speed));
    }
}
