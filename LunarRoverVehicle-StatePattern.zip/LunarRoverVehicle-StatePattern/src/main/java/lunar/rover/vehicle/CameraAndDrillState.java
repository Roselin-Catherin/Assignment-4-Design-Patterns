package lunar.rover.vehicle;

/**
 * Parent of all CameraAndDrill states. Flipping the switch always goes
 * back to Driving (AtRest).
 *
 * @author Roselin
 * @version 2.0
 */
public abstract class CameraAndDrillState implements RoverState {

    @Override
    public void flipSwitch(LunarRoverVehicle rover) {
        rover.changeTo(new AtRest());
    }
}
