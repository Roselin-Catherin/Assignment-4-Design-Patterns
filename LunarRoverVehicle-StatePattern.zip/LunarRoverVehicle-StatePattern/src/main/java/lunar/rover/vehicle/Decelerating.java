package lunar.rover.vehicle;

/**
 * Speed goes down by ACCEL every second until it reaches 0.
 *
 * @author Roselin
 * @version 2.0
 */
public class Decelerating extends ForwardState {

    @Override
    public String getName() {
        return "DECELERATING";
    }

    @Override
    public void leftPedal(LunarRoverVehicle rover, double seconds) {
        if (LunarRoverVehicle.isTap(seconds)) {
            rover.changeTo(new Accelerating());
        }
    }

    @Override
    protected void updateSpeed(LunarRoverVehicle rover, double seconds) {
        double speed = rover.getSpeed() - LunarRoverVehicle.ACCEL * seconds;
        rover.setSpeed(Math.max(0, speed));
    }
}
