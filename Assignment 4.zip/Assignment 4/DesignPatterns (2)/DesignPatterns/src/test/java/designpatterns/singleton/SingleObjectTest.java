package designpatterns.singleton;

import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * JUnit tests for the {@link SingleObject} class (Singleton pattern).
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class SingleObjectTest {

    /**
     * Tests that {@link SingleObject#getInstance()} always returns the
     * same object and that the constructor is private, so only a single
     * object can ever be created.
     */
    @Test
    public void testGetInstance() {
        System.out.println("getInstance");
        SingleObject first = SingleObject.getInstance();
        SingleObject second = SingleObject.getInstance();

        assertNotNull("getInstance() should not return null", first);
        assertSame("Both calls must return the same single object", first, second);

        Constructor<?>[] constructors = SingleObject.class.getDeclaredConstructors();
        for (Constructor<?> constructor : constructors) {
            assertTrue("Constructor must be private so no other object can be created",
                    Modifier.isPrivate(constructor.getModifiers()));
        }
    }
}
