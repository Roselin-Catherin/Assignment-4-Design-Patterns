package designpatterns.state;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * JUnit tests for the {@link Context} class and its states
 * (State pattern).
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class ContextTest {

    /**
     * The context under test, created fresh before each test.
     */
    private Context context;

    /**
     * Creates a new context before each test.
     */
    @Before
    public void setUp() {
        context = new Context();
    }

    /**
     * Tests that a new context has no state.
     */
    @Test
    public void testGetStateInitiallyNull() {
        assertNull("A new Context should have no state", context.getState());
    }

    /**
     * Tests that {@link StartState#doAction(Context)} puts the context
     * in the start state.
     */
    @Test
    public void testStartStateDoAction() {
        StartState startState = new StartState();
        startState.doAction(context);

        assertSame(startState, context.getState());
        assertEquals("Start State", context.getState().toString());
    }

    /**
     * Tests that {@link StopState#doAction(Context)} puts the context in
     * the stop state.
     */
    @Test
    public void testStopStateDoAction() {
        StopState stopState = new StopState();
        stopState.doAction(context);

        assertSame(stopState, context.getState());
        assertEquals("Stop State", context.getState().toString());
    }

    /**
     * Tests that the context's state changes from start to stop, so its
     * behaviour changes with its state.
     */
    @Test
    public void testStateChangeStartToStop() {
        new StartState().doAction(context);
        assertTrue(context.getState() instanceof StartState);

        new StopState().doAction(context);
        assertTrue(context.getState() instanceof StopState);
        assertEquals("Stop State", context.getState().toString());
    }
}
