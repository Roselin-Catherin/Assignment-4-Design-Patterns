package designpatterns.factory;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * JUnit tests for the {@link ShapeFactory} class (Factory pattern).
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class ShapeFactoryTest {

    /**
     * The factory under test, created fresh before each test.
     */
    private ShapeFactory shapeFactory;

    /**
     * Creates a new factory before each test.
     */
    @Before
    public void setUp() {
        shapeFactory = new ShapeFactory();
    }

    /**
     * Tests that asking for "CIRCLE" returns a Circle.
     */
    @Test
    public void testGetShapeCircle() {
        Shape shape = shapeFactory.getShape("CIRCLE");
        assertTrue("Expected a Circle object", shape instanceof Circle);
    }

    /**
     * Tests that asking for "RECTANGLE" returns a Rectangle.
     */
    @Test
    public void testGetShapeRectangle() {
        Shape shape = shapeFactory.getShape("RECTANGLE");
        assertTrue("Expected a Rectangle object", shape instanceof Rectangle);
    }

    /**
     * Tests that asking for "SQUARE" returns a Square.
     */
    @Test
    public void testGetShapeSquare() {
        Shape shape = shapeFactory.getShape("SQUARE");
        assertTrue("Expected a Square object", shape instanceof Square);
    }

    /**
     * Tests that the type name is not case-sensitive.
     */
    @Test
    public void testGetShapeIgnoresCase() {
        Shape shape = shapeFactory.getShape("circle");
        assertTrue("Lower-case name should still return a Circle", shape instanceof Circle);
    }

    /**
     * Tests that a null or unknown type returns null.
     */
    @Test
    public void testGetShapeInvalidType() {
        assertNull("null type should return null", shapeFactory.getShape(null));
        assertNull("Unknown type should return null", shapeFactory.getShape("TRIANGLE"));
    }
}
