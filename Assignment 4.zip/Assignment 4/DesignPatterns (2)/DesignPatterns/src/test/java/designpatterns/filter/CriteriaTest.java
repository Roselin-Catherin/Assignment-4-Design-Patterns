package designpatterns.filter;

import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * JUnit tests for the {@link Criteria} implementations (Filter
 * pattern): {@link CriteriaMale}, {@link CriteriaFemale},
 * {@link CriteriaSingle}, {@link AndCriteria} and {@link OrCriteria}.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class CriteriaTest {

    /**
     * The list of persons to filter; the same six people used in the
     * lecture demo, rebuilt before each test.
     */
    private List<Person> persons;

    /**
     * Builds the list of persons before each test.
     */
    @Before
    public void setUp() {
        persons = new ArrayList<Person>();
        persons.add(new Person("Robert", "Male", "Single"));
        persons.add(new Person("John", "Male", "Married"));
        persons.add(new Person("Laura", "Female", "Married"));
        persons.add(new Person("Diana", "Female", "Single"));
        persons.add(new Person("Mike", "Male", "Single"));
        persons.add(new Person("Bobby", "Male", "Single"));
    }

    /**
     * Returns the names of the given persons, in order.
     *
     * @param list the persons whose names are wanted.
     * @return a list of the names.
     */
    private List<String> names(List<Person> list) {
        List<String> result = new ArrayList<String>();
        for (Person person : list) {
            result.add(person.getName());
        }
        return result;
    }

    /**
     * Tests that {@link CriteriaMale} keeps only the four males.
     */
    @Test
    public void testMeetCriteriaMale() {
        List<Person> result = new CriteriaMale().meetCriteria(persons);
        assertEquals(4, result.size());
        for (Person person : result) {
            assertEquals("Male", person.getGender());
        }
    }

    /**
     * Tests that {@link CriteriaFemale} keeps only Laura and Diana.
     */
    @Test
    public void testMeetCriteriaFemale() {
        List<Person> result = new CriteriaFemale().meetCriteria(persons);
        assertEquals(2, result.size());
        assertTrue(names(result).contains("Laura"));
        assertTrue(names(result).contains("Diana"));
    }

    /**
     * Tests that {@link CriteriaSingle} keeps only the four single
     * persons.
     */
    @Test
    public void testMeetCriteriaSingle() {
        List<Person> result = new CriteriaSingle().meetCriteria(persons);
        assertEquals(4, result.size());
        for (Person person : result) {
            assertEquals("Single", person.getMaritalStatus());
        }
    }

    /**
     * Tests that {@link AndCriteria} of single and male keeps only the
     * single males: Robert, Mike and Bobby.
     */
    @Test
    public void testMeetCriteriaAnd() {
        Criteria singleMale = new AndCriteria(new CriteriaSingle(), new CriteriaMale());
        List<Person> result = singleMale.meetCriteria(persons);

        assertEquals(3, result.size());
        assertFalse("John is married and must be excluded", names(result).contains("John"));
        assertFalse("Diana is female and must be excluded", names(result).contains("Diana"));
    }

    /**
     * Tests that {@link OrCriteria} of single or female keeps the four
     * single persons plus Laura, with no duplicates.
     */
    @Test
    public void testMeetCriteriaOr() {
        Criteria singleOrFemale = new OrCriteria(new CriteriaSingle(), new CriteriaFemale());
        List<Person> result = singleOrFemale.meetCriteria(persons);

        assertEquals("Diana must not appear twice", 5, result.size());
        assertTrue(names(result).contains("Laura"));
        assertFalse("John is married and male", names(result).contains("John"));
    }
}
