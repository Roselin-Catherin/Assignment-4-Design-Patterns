package designpatterns.facade;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * JUnit tests for the {@link ShapeMaker} facade class (Facade pattern).
 * Each test checks that the facade delegates to the right hidden shape
 * by capturing what is printed to standard output.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class ShapeMakerTest {

    /**
     * Buffer that captures standard output so the printed text can be
     * checked by the assertions.
     */
    private ByteArrayOutputStream outContent;

    /**
     * The original standard output, kept so it can be restored after
     * each test.
     */
    private PrintStream originalOut;

    /**
     * The facade under test, created fresh before each test so tests
     * do not affect each other.
     */
    private ShapeMaker shapeMaker;

    /**
     * Redirects standard output to a buffer and creates the facade.
     */
    @Before
    public void setUp() {
        originalOut = System.out;
        outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));
        shapeMaker = new ShapeMaker();
    }

    /**
     * Restores the original standard output.
     */
    @After
    public void tearDown() {
        System.setOut(originalOut);
    }

    /**
     * Tests that {@link ShapeMaker#drawCircle()} delegates to Circle.
     */
    @Test
    public void testDrawCircle() {
        shapeMaker.drawCircle();
        assertEquals("Circle::draw()", outContent.toString().trim());
    }

    /**
     * Tests that {@link ShapeMaker#drawRectangle()} delegates to
     * Rectangle.
     */
    @Test
    public void testDrawRectangle() {
        shapeMaker.drawRectangle();
        assertEquals("Rectangle::draw()", outContent.toString().trim());
    }

    /**
     * Tests that {@link ShapeMaker#drawSquare()} delegates to Square.
     */
    @Test
    public void testDrawSquare() {
        shapeMaker.drawSquare();
        assertEquals("Square::draw()", outContent.toString().trim());
    }
}
