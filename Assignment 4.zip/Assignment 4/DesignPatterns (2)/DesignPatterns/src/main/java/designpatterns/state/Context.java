package designpatterns.state;

/**
 * A class that carries a {@link State}. Its behaviour changes as its
 * state object changes (State design pattern).
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class Context {

    /**
     * The current state of this context. It is stored as the
     * <code>State</code> interface so any concrete state can be
     * swapped in at run time; it is <code>null</code> until a state
     * performs its action on this context.
     */
    private State state;

    /**
     * Creates a context with no state (the state is <code>null</code>).
     */
    public Context() {
        state = null;
    }

    /**
     * Sets the current state of this context.
     *
     * @param state the new state of this context.
     * @see #getState()
     */
    public void setState(State state) {
        this.state = state;
    }

    /**
     * Returns the current state of this context.
     *
     * @return the current state; <code>null</code> if no state has been
     *         set yet.
     */
    public State getState() {
        return state;
    }
}
