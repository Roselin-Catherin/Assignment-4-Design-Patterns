package designpatterns.filter;

import java.util.ArrayList;
import java.util.List;

/**
 * A {@link Criteria} that keeps only male persons.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class CriteriaMale implements Criteria {

    /**
     * Creates a new <code>CriteriaMale</code> object.
     */
    public CriteriaMale() {
    }

    /**
     * Returns the persons whose gender is "MALE" (case ignored).
     *
     * @param persons the list of persons to filter.
     * @return a new list containing only the male persons.
     */
    @Override
    public List<Person> meetCriteria(List<Person> persons) {
        List<Person> malePersons = new ArrayList<Person>();

        for (Person person : persons) {
            if (person.getGender().equalsIgnoreCase("MALE")) {
                malePersons.add(person);
            }
        }
        return malePersons;
    }
}
