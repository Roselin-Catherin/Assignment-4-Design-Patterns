package designpatterns.factory;

/**
 * A concrete {@link Shape} representing a circle.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class Circle implements Shape {

    /**
     * Creates a new <code>Circle</code> object.
     */
    public Circle() {
    }

    /**
     * Draws this circle by printing "Inside Circle::draw() method." to
     * standard output.
     */
    @Override
    public void draw() {
        System.out.println("Inside Circle::draw() method.");
    }
}
