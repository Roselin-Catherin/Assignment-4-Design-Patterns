package designpatterns.state;

/**
 * A concrete {@link State} representing a player in the stop state.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class StopState implements State {

    /**
     * Creates a new <code>StopState</code> object.
     */
    public StopState() {
    }

    /**
     * Prints "Player is in stop state" and sets this object as the
     * current state of the context.
     *
     * @param context the context to move into the stop state.
     */
    @Override
    public void doAction(Context context) {
        System.out.println("Player is in stop state");
        context.setState(this);
    }

    /**
     * Returns a readable name for this state.
     *
     * @return the string "Stop State".
     */
    @Override
    public String toString() {
        return "Stop State";
    }
}
