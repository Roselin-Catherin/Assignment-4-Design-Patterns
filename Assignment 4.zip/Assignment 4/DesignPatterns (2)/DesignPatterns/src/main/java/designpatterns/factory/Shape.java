package designpatterns.factory;

/**
 * An interface representing a shape that can be drawn. The
 * {@link ShapeFactory} returns objects of this common type so the
 * client never needs to know the concrete class.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public interface Shape {

    /**
     * Draws this shape by printing a message to standard output.
     */
    void draw();
}
