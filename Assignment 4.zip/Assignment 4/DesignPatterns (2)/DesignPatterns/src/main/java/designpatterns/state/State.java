package designpatterns.state;

/**
 * An interface representing a state that a {@link Context} can be in
 * (State design pattern). Each concrete state defines its own action.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public interface State {

    /**
     * Performs the action for this state and makes this state the
     * current state of the given context.
     *
     * @param context the context whose state is being changed.
     */
    public void doAction(Context context);
}
