package designpatterns;

import designpatterns.facade.FacadePatternDemo;
import designpatterns.factory.FactoryPatternDemo;
import designpatterns.filter.CriteriaPatternDemo;
import designpatterns.singleton.SingletonPatternDemo;
import designpatterns.state.StatePatternDemo;

/**
 * Entry point for the whole project. Runs the demo class of every
 * design pattern one after another, printing a heading before each so
 * the output of each pattern can be told apart.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class Main {

    /**
     * Creates a new <code>Main</code> object.
     */
    public Main() {
    }

    /**
     * Runs the Singleton, Facade, Factory, State and Filter demos in
     * order.
     *
     * @param args command-line arguments (not used).
     */
    public static void main(String[] args) {
        printHeading("1. SINGLETON PATTERN");
        SingletonPatternDemo.main(args);

        printHeading("2. FACADE PATTERN");
        FacadePatternDemo.main(args);

        printHeading("3. FACTORY PATTERN");
        FactoryPatternDemo.main(args);

        printHeading("4. STATE PATTERN");
        StatePatternDemo.main(args);

        printHeading("5. FILTER PATTERN");
        CriteriaPatternDemo.main(args);
    }

    /**
     * Prints a heading line so each demo's output is easy to find.
     *
     * @param title the text to show in the heading.
     */
    private static void printHeading(String title) {
        System.out.println();
        System.out.println("========== " + title + " ==========");
    }
}
