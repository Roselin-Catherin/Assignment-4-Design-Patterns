package designpatterns.facade;

/**
 * A facade class that hides the concrete shape classes from the client
 * (Facade design pattern). The client calls simple methods such as
 * {@link #drawCircle()} and this class delegates the call to the
 * matching {@link Shape} object.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class ShapeMaker {

    /**
     * The circle that drawing requests are delegated to. Kept private so
     * the client never deals with the <code>Circle</code> class directly.
     */
    private Shape circle;

    /**
     * The rectangle that drawing requests are delegated to. Kept private
     * so the client never deals with the <code>Rectangle</code> class
     * directly.
     */
    private Shape rectangle;

    /**
     * The square that drawing requests are delegated to. Kept private so
     * the client never deals with the <code>Square</code> class directly.
     */
    private Shape square;

    /**
     * Creates a facade and the circle, rectangle and square objects it
     * delegates to.
     */
    public ShapeMaker() {
        circle = new Circle();
        rectangle = new Rectangle();
        square = new Square();
    }

    /**
     * Draws a circle by delegating to the hidden <code>Circle</code>.
     */
    public void drawCircle() {
        circle.draw();
    }

    /**
     * Draws a rectangle by delegating to the hidden <code>Rectangle</code>.
     */
    public void drawRectangle() {
        rectangle.draw();
    }

    /**
     * Draws a square by delegating to the hidden <code>Square</code>.
     */
    public void drawSquare() {
        square.draw();
    }
}
