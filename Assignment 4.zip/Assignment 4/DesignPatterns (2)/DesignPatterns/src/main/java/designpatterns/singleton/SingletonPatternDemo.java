package designpatterns.singleton;

/**
 * Demo class showing how a client gets and uses the single
 * {@link SingleObject} instance.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 * @see SingleObject
 */
public class SingletonPatternDemo {

    /**
     * Creates a new <code>SingletonPatternDemo</code> object.
     */
    public SingletonPatternDemo() {
    }

    /**
     * Gets the only available <code>SingleObject</code> and shows its
     * message. Calling <code>new SingleObject()</code> here would be a
     * compile-time error because the constructor is not visible.
     *
     * @param args command-line arguments (not used).
     */
    public static void main(String[] args) {
        // illegal construct
        // Compile Time Error: The constructor SingleObject() is not visible
        // SingleObject object = new SingleObject();

        // Get the only object available
        SingleObject object = SingleObject.getInstance();

        // show the message
        object.showMessage();
    }
}
