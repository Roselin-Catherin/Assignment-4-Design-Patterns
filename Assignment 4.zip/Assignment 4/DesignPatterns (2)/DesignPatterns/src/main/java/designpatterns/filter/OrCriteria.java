package designpatterns.filter;

import java.util.List;

/**
 * A {@link Criteria} that combines two criteria with a logical OR: a
 * person is kept if they meet either one.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class OrCriteria implements Criteria {

    /**
     * The first criterion. Stored as the <code>Criteria</code>
     * interface so any criterion can be combined.
     */
    private Criteria criteria;

    /**
     * The second criterion. Stored as the <code>Criteria</code>
     * interface so any criterion can be combined.
     */
    private Criteria otherCriteria;

    /**
     * Creates an OR criterion from two criteria.
     *
     * @param criteria the first criterion.
     * @param otherCriteria the second criterion.
     */
    public OrCriteria(Criteria criteria, Criteria otherCriteria) {
        this.criteria = criteria;
        this.otherCriteria = otherCriteria;
    }

    /**
     * Returns the persons that meet at least one of the two criteria.
     * Persons from the second result are added only if they are not
     * already in the first, so nobody appears twice.
     *
     * @param persons the list of persons to filter.
     * @return a new list containing the persons that meet either
     *         criterion, without duplicates.
     */
    @Override
    public List<Person> meetCriteria(List<Person> persons) {
        List<Person> firstCriteriaItems = criteria.meetCriteria(persons);
        List<Person> otherCriteriaItems = otherCriteria.meetCriteria(persons);

        for (Person person : otherCriteriaItems) {
            if (!firstCriteriaItems.contains(person)) {
                firstCriteriaItems.add(person);
            }
        }
        return firstCriteriaItems;
    }
}
