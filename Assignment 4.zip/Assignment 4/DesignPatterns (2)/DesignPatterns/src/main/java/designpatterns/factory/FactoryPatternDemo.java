package designpatterns.factory;

/**
 * Demo class that uses the {@link ShapeFactory} to get objects of
 * concrete classes by passing a type name.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 * @see ShapeFactory
 */
public class FactoryPatternDemo {

    /**
     * Creates a new <code>FactoryPatternDemo</code> object.
     */
    public FactoryPatternDemo() {
    }

    /**
     * Gets a circle, a rectangle and a square from the factory and
     * draws each of them.
     *
     * @param args command-line arguments (not used).
     */
    public static void main(String[] args) {
        ShapeFactory shapeFactory = new ShapeFactory();

        // get an object of Circle and call its draw method.
        Shape shape1 = shapeFactory.getShape("CIRCLE");

        // call draw method of Circle
        shape1.draw();

        // get an object of Rectangle and call its draw method.
        Shape shape2 = shapeFactory.getShape("RECTANGLE");

        // call draw method of Rectangle
        shape2.draw();

        // get an object of Square and call its draw method.
        Shape shape3 = shapeFactory.getShape("SQUARE");

        // call draw method of square
        shape3.draw();
    }
}
