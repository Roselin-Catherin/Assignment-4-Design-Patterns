package designpatterns.filter;

/**
 * A person on whom filtering criteria are applied (Filter design
 * pattern).
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class Person {

    /**
     * The name of this person, used to identify the person in output.
     * Private so it can only be read through {@link #getName()}.
     */
    private String name;

    /**
     * The gender of this person ("Male" or "Female"). Used by
     * {@link CriteriaMale} and {@link CriteriaFemale} to filter people.
     */
    private String gender;

    /**
     * The marital status of this person ("Single" or "Married"). Used
     * by {@link CriteriaSingle} to filter people.
     */
    private String maritalStatus;

    /**
     * Creates a person with the given name, gender and marital status.
     *
     * @param name the name of the person.
     * @param gender the gender of the person, e.g. "Male" or "Female".
     * @param maritalStatus the marital status, e.g. "Single" or
     *        "Married".
     */
    public Person(String name, String gender, String maritalStatus) {
        this.name = name;
        this.gender = gender;
        this.maritalStatus = maritalStatus;
    }

    /**
     * Returns the name of this person.
     *
     * @return the name of this person.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the gender of this person.
     *
     * @return the gender of this person.
     */
    public String getGender() {
        return gender;
    }

    /**
     * Returns the marital status of this person.
     *
     * @return the marital status of this person.
     */
    public String getMaritalStatus() {
        return maritalStatus;
    }
}
