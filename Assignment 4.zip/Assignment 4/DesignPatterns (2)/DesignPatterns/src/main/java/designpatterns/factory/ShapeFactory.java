package designpatterns.factory;

/**
 * A factory that creates {@link Shape} objects from a type name
 * (Factory design pattern). The creation logic is hidden from the
 * client, which refers to the new object only through the
 * <code>Shape</code> interface.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class ShapeFactory {

    /**
     * Creates a new <code>ShapeFactory</code> object.
     */
    public ShapeFactory() {
    }

    /**
     * Returns a new shape object of the requested type. The comparison
     * ignores case, so "circle" and "CIRCLE" give the same result.
     *
     * @param shapeType the type of shape to create: "CIRCLE",
     *        "RECTANGLE" or "SQUARE".
     * @return a new <code>Circle</code>, <code>Rectangle</code> or
     *         <code>Square</code>; <code>null</code> if
     *         <code>shapeType</code> is <code>null</code> or not a known
     *         type.
     */
    public Shape getShape(String shapeType) {
        if (shapeType == null) {
            return null;
        }
        if (shapeType.equalsIgnoreCase("CIRCLE")) {
            return new Circle();

        } else if (shapeType.equalsIgnoreCase("RECTANGLE")) {
            return new Rectangle();

        } else if (shapeType.equalsIgnoreCase("SQUARE")) {
            return new Square();
        }

        return null;
    }
}
