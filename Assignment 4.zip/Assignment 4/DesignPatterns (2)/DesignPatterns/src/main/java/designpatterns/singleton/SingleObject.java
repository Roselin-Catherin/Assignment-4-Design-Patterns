package designpatterns.singleton;

/**
 * A class that allows only one instance of itself to be created
 * (Singleton design pattern). The constructor is private, so other
 * classes cannot use <code>new</code>; they must call
 * {@link #getInstance()} to get the single shared object.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class SingleObject {

    /**
     * The only instance of this class. It is <code>static</code> so it
     * belongs to the class rather than to any object, and it is created
     * once when the class is loaded (eager initialization), which also
     * makes it thread-safe without synchronization. It is
     * <code>private</code> so no outside class can replace it.
     */
    private static SingleObject instance = new SingleObject();

    /**
     * Creates the single object. The constructor is <code>private</code>
     * so that this class cannot be instantiated from outside, which
     * guarantees that only one object is ever created.
     */
    private SingleObject() {
    }

    /**
     * Returns the only object available of this class.
     *
     * @return the single shared instance of <code>SingleObject</code>;
     *         the same object is returned on every call.
     */
    public static SingleObject getInstance() {
        return instance;
    }

    /**
     * Prints the message "Hello World!" to standard output.
     */
    public void showMessage() {
        System.out.println("Hello World!");
    }
}
