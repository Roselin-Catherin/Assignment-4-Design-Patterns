package designpatterns.state;

/**
 * A concrete {@link State} representing a player in the start state.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class StartState implements State {

    /**
     * Creates a new <code>StartState</code> object.
     */
    public StartState() {
    }

    /**
     * Prints "Player is in start state" and sets this object as the
     * current state of the context.
     *
     * @param context the context to move into the start state.
     */
    @Override
    public void doAction(Context context) {
        System.out.println("Player is in start state");
        context.setState(this);
    }

    /**
     * Returns a readable name for this state.
     *
     * @return the string "Start State".
     */
    @Override
    public String toString() {
        return "Start State";
    }
}
