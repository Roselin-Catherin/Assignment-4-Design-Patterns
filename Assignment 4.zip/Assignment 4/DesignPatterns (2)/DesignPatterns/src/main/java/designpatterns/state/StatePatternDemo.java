package designpatterns.state;

/**
 * Demo class that uses a {@link Context} to show the change in
 * behaviour when its {@link State} changes.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 * @see Context
 */
public class StatePatternDemo {

    /**
     * Creates a new <code>StatePatternDemo</code> object.
     */
    public StatePatternDemo() {
    }

    /**
     * Moves a context into the start state and then the stop state,
     * printing the current state after each change.
     *
     * @param args command-line arguments (not used).
     */
    public static void main(String[] args) {
        Context context = new Context();

        StartState startState = new StartState();
        startState.doAction(context);

        System.out.println(context.getState().toString());

        StopState stopState = new StopState();
        stopState.doAction(context);

        System.out.println(context.getState().toString());
    }
}
