package designpatterns.filter;

import java.util.ArrayList;
import java.util.List;

/**
 * A {@link Criteria} that keeps only single persons.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class CriteriaSingle implements Criteria {

    /**
     * Creates a new <code>CriteriaSingle</code> object.
     */
    public CriteriaSingle() {
    }

    /**
     * Returns the persons whose marital status is "SINGLE" (case
     * ignored).
     *
     * @param persons the list of persons to filter.
     * @return a new list containing only the single persons.
     */
    @Override
    public List<Person> meetCriteria(List<Person> persons) {
        List<Person> singlePersons = new ArrayList<Person>();

        for (Person person : persons) {
            if (person.getMaritalStatus().equalsIgnoreCase("SINGLE")) {
                singlePersons.add(person);
            }
        }
        return singlePersons;
    }
}
