package designpatterns.facade;

/**
 * Demo class that uses the {@link ShapeMaker} facade to draw various
 * types of shapes.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 * @see ShapeMaker
 */
public class FacadePatternDemo {

    /**
     * Creates a new <code>FacadePatternDemo</code> object.
     */
    public FacadePatternDemo() {
    }

    /**
     * Creates a <code>ShapeMaker</code> and draws a circle, a rectangle
     * and a square through it.
     *
     * @param args command-line arguments (not used).
     */
    public static void main(String[] args) {
        ShapeMaker shapeMaker = new ShapeMaker();

        shapeMaker.drawCircle();
        shapeMaker.drawRectangle();
        shapeMaker.drawSquare();
    }
}
