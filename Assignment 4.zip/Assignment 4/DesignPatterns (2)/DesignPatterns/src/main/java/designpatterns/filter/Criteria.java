package designpatterns.filter;

import java.util.List;

/**
 * An interface for a criterion used to filter a list of {@link Person}
 * objects (Filter design pattern). Criteria can be chained through
 * {@link AndCriteria} and {@link OrCriteria}.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public interface Criteria {

    /**
     * Returns the persons from the given list that meet this criterion.
     *
     * @param persons the list of persons to filter.
     * @return a new list containing only the persons that meet this
     *         criterion; empty if none do.
     */
    public List<Person> meetCriteria(List<Person> persons);
}
