package designpatterns.filter;

import java.util.ArrayList;
import java.util.List;

/**
 * Demo class that uses {@link Criteria} objects to filter a list of
 * {@link Person} objects by various criteria and their combinations.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 * @see Criteria
 */
public class CriteriaPatternDemo {

    /**
     * Creates a new <code>CriteriaPatternDemo</code> object.
     */
    public CriteriaPatternDemo() {
    }

    /**
     * Builds a list of persons and prints the males, the females, the
     * single males, and the persons who are single or female.
     *
     * @param args command-line arguments (not used).
     */
    public static void main(String[] args) {
        List<Person> persons = new ArrayList<Person>();

        persons.add(new Person("Robert", "Male", "Single"));
        persons.add(new Person("John", "Male", "Married"));
        persons.add(new Person("Laura", "Female", "Married"));
        persons.add(new Person("Diana", "Female", "Single"));
        persons.add(new Person("Mike", "Male", "Single"));
        persons.add(new Person("Bobby", "Male", "Single"));

        Criteria male = new CriteriaMale();
        Criteria female = new CriteriaFemale();
        Criteria single = new CriteriaSingle();
        Criteria singleMale = new AndCriteria(single, male);
        Criteria singleOrFemale = new OrCriteria(single, female);

        System.out.println("Males: ");
        printPersons(male.meetCriteria(persons));

        System.out.println("\nFemales: ");
        printPersons(female.meetCriteria(persons));

        System.out.println("\nSingle Males: ");
        printPersons(singleMale.meetCriteria(persons));

        System.out.println("\nSingle Or Females: ");
        printPersons(singleOrFemale.meetCriteria(persons));
    }

    /**
     * Prints the name, gender and marital status of each person in the
     * list, one person per line.
     *
     * @param persons the list of persons to print.
     */
    public static void printPersons(List<Person> persons) {
        for (Person person : persons) {
            System.out.println("Person : [ Name : " + person.getName()
                    + ", Gender : " + person.getGender()
                    + ", Marital Status : " + person.getMaritalStatus() + " ]");
        }
    }
}
