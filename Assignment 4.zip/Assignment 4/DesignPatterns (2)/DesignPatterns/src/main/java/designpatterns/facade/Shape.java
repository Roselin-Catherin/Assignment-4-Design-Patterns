package designpatterns.facade;

/**
 * An interface representing a shape that can be drawn. It is the
 * common type for the concrete shapes hidden behind the
 * {@link ShapeMaker} facade.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public interface Shape {

    /**
     * Draws this shape by printing a message to standard output.
     */
    void draw();
}
