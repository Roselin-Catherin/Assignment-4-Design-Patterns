package designpatterns.filter;

import java.util.List;

/**
 * A {@link Criteria} that combines two criteria with a logical AND: a
 * person is kept only if they meet both.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class AndCriteria implements Criteria {

    /**
     * The first criterion, applied to the full list. Stored as the
     * <code>Criteria</code> interface so any criterion can be chained.
     */
    private Criteria criteria;

    /**
     * The second criterion, applied to the result of the first one.
     * Stored as the <code>Criteria</code> interface so any criterion
     * can be chained.
     */
    private Criteria otherCriteria;

    /**
     * Creates an AND criterion from two criteria.
     *
     * @param criteria the first criterion to apply.
     * @param otherCriteria the second criterion to apply.
     */
    public AndCriteria(Criteria criteria, Criteria otherCriteria) {
        this.criteria = criteria;
        this.otherCriteria = otherCriteria;
    }

    /**
     * Returns the persons that meet both criteria. The first criterion
     * filters the list, then the second filters that result.
     *
     * @param persons the list of persons to filter.
     * @return a new list containing only the persons that meet both
     *         criteria.
     */
    @Override
    public List<Person> meetCriteria(List<Person> persons) {
        List<Person> firstCriteriaPersons = criteria.meetCriteria(persons);
        return otherCriteria.meetCriteria(firstCriteriaPersons);
    }
}
