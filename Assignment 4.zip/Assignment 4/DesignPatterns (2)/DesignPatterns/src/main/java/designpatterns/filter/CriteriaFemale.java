package designpatterns.filter;

import java.util.ArrayList;
import java.util.List;

/**
 * A {@link Criteria} that keeps only female persons.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class CriteriaFemale implements Criteria {

    /**
     * Creates a new <code>CriteriaFemale</code> object.
     */
    public CriteriaFemale() {
    }

    /**
     * Returns the persons whose gender is "FEMALE" (case ignored).
     *
     * @param persons the list of persons to filter.
     * @return a new list containing only the female persons.
     */
    @Override
    public List<Person> meetCriteria(List<Person> persons) {
        List<Person> femalePersons = new ArrayList<Person>();

        for (Person person : persons) {
            if (person.getGender().equalsIgnoreCase("FEMALE")) {
                femalePersons.add(person);
            }
        }
        return femalePersons;
    }
}
