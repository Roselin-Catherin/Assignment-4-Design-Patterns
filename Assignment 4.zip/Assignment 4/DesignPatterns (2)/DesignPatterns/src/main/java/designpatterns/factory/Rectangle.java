package designpatterns.factory;

/**
 * A concrete {@link Shape} representing a rectangle.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class Rectangle implements Shape {

    /**
     * Creates a new <code>Rectangle</code> object.
     */
    public Rectangle() {
    }

    /**
     * Draws this rectangle by printing
     * "Inside Rectangle::draw() method." to standard output.
     */
    @Override
    public void draw() {
        System.out.println("Inside Rectangle::draw() method.");
    }
}
