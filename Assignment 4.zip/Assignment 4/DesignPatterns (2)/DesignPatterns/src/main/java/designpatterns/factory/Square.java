package designpatterns.factory;

/**
 * A concrete {@link Shape} representing a square.
 *
 * @author Roselin
 * @version 1.0 (11/24/26)
 * @since version 1.0
 */
public class Square implements Shape {

    /**
     * Creates a new <code>Square</code> object.
     */
    public Square() {
    }

    /**
     * Draws this square by printing "Inside Square::draw() method." to
     * standard output.
     */
    @Override
    public void draw() {
        System.out.println("Inside Square::draw() method.");
    }
}
