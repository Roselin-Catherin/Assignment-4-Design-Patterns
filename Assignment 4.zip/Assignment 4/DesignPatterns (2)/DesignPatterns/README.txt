DesignPatterns - NetBeans project (Maven, JUnit 4)
Author: Roselin   Version: 1.0

OPEN IN NETBEANS
  File > Open Project > select the "DesignPatterns" folder (it shows a Maven icon).
  The first build downloads JUnit 4.13.2 automatically (needs internet).

RUN
  Tests:   right-click project > Test   (or Alt+F6)    -> 18 tests
  All demos: Run Project (F6) runs designpatterns.Main, which runs all 5 demos
  One demo:  right-click its *PatternDemo.java > Run File (Shift+F6)
  JavaDoc: right-click project > Generate Javadoc
           (pre-generated HTML is also in the "javadoc" folder: open javadoc/index.html)

PACKAGES (src/main/java)               TESTS (src/test/java)
  designpatterns.singleton               SingleObjectTest   (1 test)
  designpatterns.facade                  ShapeMakerTest     (3 tests)
  designpatterns.factory                 ShapeFactoryTest   (5 tests)
  designpatterns.state                   ContextTest        (4 tests)
  designpatterns.filter                  CriteriaTest       (5 tests)

Each pattern is in its own package because Facade and Factory both use
classes named Shape, Circle, Rectangle and Square (as in the lecture).
